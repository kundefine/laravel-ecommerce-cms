<?php 




return [ 'all_product' => \App\Product::class ];
