<?php


namespace App\Setting;


class Setting {
    
}